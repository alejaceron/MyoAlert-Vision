package com.example.myoalert_vision_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
