import numpy as np

def flatten_signal(filtered_signals, signal_names):

    flattened_signal = filtered_signals.flatten()
    return flattened_signal
